package W19Project2GIVETOSTUDENTS;


public enum GameStatus {
    Lost, Won, NotOverYet
}
